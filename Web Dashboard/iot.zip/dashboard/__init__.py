from flask import Flask 
from flask_socketio import SocketIO

app = Flask(__name__)
socketio = SocketIO(app)
app.config['secret_key']= '539dd33ccf3748f2aec5c04db8acd3eb'

from dashboard import routes,model