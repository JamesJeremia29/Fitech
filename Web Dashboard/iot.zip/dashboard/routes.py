from flask import render_template,jsonify,url_for,redirect
from dashboard import app
from dashboard.model import query1,query_wo_tday,query2,query5,query6, join_q3      
from dashboard.func import q_to_list,get_column_data,get_dict_column_data,unnest,to_graph_data,to_graph_data_2



@app.route('/')
def dashboard_page():
    global data2
    data1 = 'api1'
    data2 = len(q_to_list(query2))                                  
    data3 = get_dict_column_data(query_wo_tday,join_q3)
    data4 = len(get_column_data(query_wo_tday,'user_id'))           
    data5 = 'api2'
    data6 = get_column_data(query6,'country',in_dict=True)         
    data = [data1,data2,data3,data4,data5,data6]
    return render_template('index.html', data=data)

@app.route('/api/data1')
def data_for_graph():
    data1 = q_to_list(query1,column='time_started')
    data1 = to_graph_data(data1,column='')
    return jsonify(data1)

@app.route('/api/data2')
def data_for_graph_2():
    data5 = q_to_list(query5)
    return jsonify(data5)

#print(callback_done)